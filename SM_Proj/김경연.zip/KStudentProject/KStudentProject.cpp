﻿#include "KStudentManager.h"

int main() {


	KStudentManager KSM;
	KSM.Run();
	return 0;



}
